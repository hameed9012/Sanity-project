import { notFound, redirect } from "next/navigation";
import ArticleTemplate from "@/components/articles/ArticleTemplate";
import articlesData from "@/data/articles/articles-data";
import ArticleViewClient from "@/components/ArticleViewClient";

// If you ever rename slugs, map old → new here.
const slugAliases = {
  "dubai-off-plan-investment-guide": "off-plan-investment-dubai",
};

function tryCall(fn) {
  try {
    return fn();
  } catch {
    return null;
  }
}

function getArticleSafe(slug) {
  const get = articlesData?.getArticleBySlug;

  // Try many common signatures
  const direct =
    tryCall(() => get?.(slug, "en")) ||
    tryCall(() => get?.("en", slug)) ||
    tryCall(() => get?.({ slug, locale: "en" })) ||
    tryCall(() => get?.({ locale: "en", slug })) ||
    tryCall(() => get?.(slug, "ar")) ||
    tryCall(() => get?.("ar", slug)) ||
    tryCall(() => get?.({ slug, locale: "ar" })) ||
    tryCall(() => get?.({ locale: "ar", slug })) ||
    tryCall(() => get?.(slug));

  if (direct) return direct;

  // Fallback: search listing arrays
  const listEn = tryCall(() => articlesData?.getAllArticles?.("en")) || [];
  const listAr = tryCall(() => articlesData?.getAllArticles?.("ar")) || [];
  const listAll = tryCall(() => articlesData?.getAllArticles?.()) || [];

  const merged = [...listEn, ...listAr, ...listAll].filter(Boolean);
  return merged.find((a) => a?.slug === slug) || null;
}

// ✅ Next (sync dynamic APIs): params is Promise → must await it
export default async function ArticlePage({ params }) {
  const { slug } = await params;

  if (!slug) return notFound();

  const resolved = slugAliases[slug] || slug;

  if (slugAliases[slug]) {
    redirect(`/articles/${resolved}`);
  }

  const article = getArticleSafe(resolved);
  if (!article) return notFound();

  const title = article.articleData?.hero?.title || "Article";

  return (
    <ArticleViewClient slug={resolved} title={title}>
      <ArticleTemplate article={article} slug={resolved} />
    </ArticleViewClient>
  );
}

export async function generateStaticParams() {
  const slugs = new Set();

  const en = tryCall(() => articlesData?.getAllArticles?.("en")) || [];
  const ar = tryCall(() => articlesData?.getAllArticles?.("ar")) || [];
  const all = tryCall(() => articlesData?.getAllArticles?.()) || [];

  [...en, ...ar, ...all].forEach((a) => {
    if (a?.slug) slugs.add(a.slug);
  });

  return Array.from(slugs).map((slug) => ({ slug }));
}

// ✅ ctx.params is Promise too → await it
export async function generateMetadata({ params }) {
  const { slug } = await params;

  if (!slug) return { title: "Articles" };

  const resolved = slugAliases[slug] || slug;
  const article = getArticleSafe(resolved);

  if (!article) return { title: "Article Not Found" };

  const title = article.articleData?.hero?.title || "Article";
  const description = article.articleData?.hero?.subtitle || "";
  const image = article.image || article.articleData?.hero?.image;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      images: image ? [image] : [],
      type: "article",
    },
  };
}
